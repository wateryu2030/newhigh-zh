
CREATE DATABASE IF NOT EXISTS stock_db DEFAULT CHARSET utf8mb4;
USE stock_db;

-- 1. 股票基础信息
CREATE TABLE IF NOT EXISTS stock_basic_info (
    ts_code VARCHAR(20) PRIMARY KEY,
    symbol VARCHAR(20),
    name VARCHAR(100),
    area VARCHAR(50),
    industry VARCHAR(100),
    market VARCHAR(20),
    list_date DATE,
    delist_date DATE,
    is_hs VARCHAR(5)
);

-- 2. 财务与估值快照（来自日频/实时表的聚合，也可直接存日频）
CREATE TABLE IF NOT EXISTS stock_financials (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    ts_code VARCHAR(20),
    trade_date DATE,
    pe DOUBLE,
    pb DOUBLE,
    ps DOUBLE,
    pcf DOUBLE,
    roe DOUBLE,
    roa DOUBLE,
    eps DOUBLE,
    bps DOUBLE,
    total_mv DOUBLE,
    circ_mv DOUBLE,
    revenue_yoy DOUBLE,
    net_profit_yoy DOUBLE,
    gross_profit_margin DOUBLE,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(ts_code, trade_date)
);

-- 3. 日行情（K线）
CREATE TABLE IF NOT EXISTS stock_market_daily (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    ts_code VARCHAR(20),
    trade_date DATE,
    open DOUBLE,
    high DOUBLE,
    low DOUBLE,
    close DOUBLE,
    pre_close DOUBLE,
    pct_chg DOUBLE,
    vol BIGINT,
    amount DOUBLE,
    turnover_rate DOUBLE,
    amplitude DOUBLE,
    update_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(ts_code, trade_date)
);
