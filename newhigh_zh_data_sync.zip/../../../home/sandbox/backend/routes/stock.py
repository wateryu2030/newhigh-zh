
from fastapi import APIRouter
from fastapi.responses import JSONResponse
import subprocess
import os
from utils.db_utils import get_engine
from config import DB_URL

stock_router = APIRouter()

# 获取基础信息的API
@stock_router.get("/stock/basic")
async def get_stock_basic():
    engine = get_engine(DB_URL)
    query = "SELECT * FROM stock_basic_info LIMIT 10;"
    df = pd.read_sql(query, engine)
    return JSONResponse(content={"data": df.to_dict(orient="records")})

# 触发数据同步的API
@stock_router.post("/data_sync")
async def run_data_sync():
    try:
        result = subprocess.run(
            ["python3", "data_engine/update_all.py"],
            capture_output=True,
            text=True,
            timeout=600
        )
        if result.returncode == 0:
            return JSONResponse(status_code=200, content={"status": "success", "message": "数据更新成功"})
        else:
            return JSONResponse(status_code=500, content={"status": "error", "message": result.stderr})
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e)})
