
from fastapi import FastAPI
from routes.stock import stock_router

app = FastAPI()

# 注册股票数据相关的API路由
app.include_router(stock_router)
